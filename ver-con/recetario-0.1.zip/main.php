<?php
/*
Plugin Name: Libro de Recetas
Plugin URI: https://github.com/elgatosaez/recetario
Description: Libro de Recetas para Centro Médico Maktub.
Version: 0.1
Author: Sebastián Sáez M.
Author URI: https://gentes.cl
License: Revista Gentes License Agreement
*/

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Basic plugin functionality
function my_basic_plugin_init() {
    // Plugin initialization code here
    add_action('admin_notices', 'my_basic_plugin_admin_notice');
}

function my_basic_plugin_admin_notice() {
    echo '<div class="notice notice-success is-dismissible">
            <p>My Basic Plugin is successfully activated!</p>
         </div>';
}

// Hook to initialize plugin
add_action('init', 'my_basic_plugin_init');
